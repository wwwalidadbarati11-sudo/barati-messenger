package com.barati.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview

private val Navy = Color(0xFF172B59)
private val Blue = Color(0xFF2455A8)
private val Pale = Color(0xFFEAF1FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BaratiApp() }
    }
}

data class Chat(val name: String, val message: String, val time: String, val initials: String)

@Composable
fun BaratiApp() {
    var selected by remember { mutableStateOf("گفتگو") }
    var search by remember { mutableStateOf("") }
    val chats = listOf(
        Chat("احمد", "سلام، خوبی؟", "۲۰:۴۵", "ا"),
        Chat("محمد", "عکس را فرستادم", "۱۹:۳۰", "م"),
        Chat("دوستان", "فردا همدیگر را می‌بینیم", "۱۸:۱۰", "د"),
        Chat("علی", "بعداً تماس می‌گیرم", "۱۷:۲۰", "ع")
    )

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Navy)) {
        Scaffold(
            containerColor = Color(0xFFF7F9FD),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val tabs = listOf(
                        "گفتگو" to Icons.Default.Chat,
                        "تماس" to Icons.Default.Call,
                        "استوری" to Icons.Default.AddCircle,
                        "کانال" to Icons.Default.Campaign,
                        "من" to Icons.Default.Person
                    )
                    tabs.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = selected == label,
                            onClick = { selected = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Header()
                when (selected) {
                    "گفتگو" -> {
                        OutlinedTextField(
                            value = search,
                            onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                            placeholder = { Text("جستجوی دوستان و گفتگوها") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp)
                        )
                        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                            items(chats.filter { it.name.contains(search) || it.message.contains(search) }) { chat ->
                                ChatRow(chat)
                            }
                        }
                    }
                    "تماس" -> PlaceholderPage("تماس‌های براتی", "در نسخه بعدی تماس صوتی و تصویری فعال می‌شود.", Icons.Default.Call)
                    "استوری" -> PlaceholderPage("استوری دوستان", "در این بخش می‌توانی استوری دوستان را ببینی و استوری خودت را منتشر کنی.", Icons.Default.AddCircle)
                    "کانال" -> PlaceholderPage("کانال‌های عمومی", "کانال‌ها و مطالب عمومی براتی در این قسمت نمایش داده می‌شوند.", Icons.Default.Campaign)
                    else -> PlaceholderPage("پروفایل من", "تنظیمات حساب، عکس پروفایل و حریم خصوصی.", Icons.Default.Person)
                }
            }
        }
    }
}

@Composable
fun Header() {
    Row(
        modifier = Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(shape = RoundedCornerShape(13.dp), color = Color.White, modifier = Modifier.size(46.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Forum, contentDescription = null, tint = Blue, modifier = Modifier.size(28.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("BARATI", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("ارتباط آسان، همیشه و همه‌جا", color = Color(0xFFD6E4FF), fontSize = 11.sp)
        }
        Icon(Icons.Default.NotificationsNone, contentDescription = "اعلان‌ها", tint = Color.White)
    }
}

@Composable
fun ChatRow(chat: Chat) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(shape = CircleShape, color = Pale, modifier = Modifier.size(52.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Text(chat.initials, color = Blue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(chat.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = Color(0xFF202633))
            Spacer(Modifier.height(4.dp))
            Text(chat.message, color = Color(0xFF707887), fontSize = 13.sp)
        }
        Text(chat.time, color = Color(0xFF8A92A0), fontSize = 11.sp)
    }
    HorizontalDivider(color = Color(0xFFE9EDF4), modifier = Modifier.padding(start = 80.dp))
}

@Composable
fun PlaceholderPage(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(shape = CircleShape, color = Pale, modifier = Modifier.size(88.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Blue, modifier = Modifier.size(42.dp))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(8.dp))
        Text(description, fontSize = 14.sp, color = Color.Gray, textAlign = TextAlign.Center, lineHeight = 22.sp)
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewBarati() {
    BaratiApp()
}
