
package com.barati.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                BaratiApp(this)
            }
        }
    }
}

@Composable
fun BaratiApp(activity: ComponentActivity) {

    val auth = remember { FirebaseAuth.getInstance() }

    var phone by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var loggedIn by remember {
        mutableStateOf(auth.currentUser != null)
    }

    fun signInWithCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener(activity) { task ->
                loading = false
                if (task.isSuccessful) {
                    loggedIn = true
                    errorMessage = ""
                } else {
                    errorMessage =
                        task.exception?.localizedMessage ?: "تأیید کد ناموفق بود"
                }
            }
    }

    fun sendVerificationCode() {
        if (!phone.trim().startsWith("+") || phone.trim().length < 8) {
            errorMessage = "شماره را با کد کشور وارد کنید؛ مثلاً +49123456789"
            return
        }

        loading = true
        errorMessage = ""

        val callbacks =
            object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                override fun onVerificationCompleted(
                    credential: PhoneAuthCredential
                ) {
                    signInWithCredential(credential)
                }

                override fun onVerificationFailed(
                    e: FirebaseException
                ) {
                    loading = false
                    errorMessage =
                        e.localizedMessage ?: "ارسال کد با خطا مواجه شد"
                }

                override fun onCodeSent(
                    id: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    verificationId = id
                    loading = false
                    errorMessage = "کد تأیید ارسال شد."
                }
            }

        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone.trim())
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .build()

        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun verifyCode() {
        val id = verificationId

        if (id == null || code.length < 6) {
            errorMessage = "کد تأیید شش‌رقمی را وارد کنید."
            return
        }

        loading = true
        errorMessage = ""

        val credential =
            PhoneAuthProvider.getCredential(id, code.trim())

        signInWithCredential(credential)
    }

    if (loggedIn) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "BARATI",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(Modifier.height(20.dp))

            Text("ورود شما موفقیت‌آمیز بود.")

            Spacer(Modifier.height(16.dp))

            Button(onClick = {
                auth.signOut()
                loggedIn = false
                phone = ""
                code = ""
                verificationId = null
            }) {
                Text("خروج از حساب")
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "BARATI MESSENGER",
                fontSize = 27.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(Modifier.height(12.dp))

            Text(
                "ارتباط آسان، همیشه و همه‌جا",
                fontSize = 14.sp
            )

            Spacer(Modifier.height(35.dp))

            Text(
                if (verificationId == null)
                    "ورود با شماره موبایل"
                else
                    "کد تأیید پیامکی را وارد کنید",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(20.dp))

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                modifier = Modifier.fillMaxWidth(),
                enabled = verificationId == null && !loading,
                label = { Text("شماره موبایل با کد کشور") },
                placeholder = { Text("+49123456789") },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone
                ),
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )

            if (verificationId != null) {
                Spacer(Modifier.height(14.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = {
                        code = it.filter { c -> c.isDigit() }
                            .take(6)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("کد شش‌رقمی") },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
            }

            Spacer(Modifier.height(20.dp))

            Button(
                onClick = {
                    if (verificationId == null) {
                        sendVerificationCode()
                    } else {
                        verifyCode()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                enabled = !loading,
                shape = RoundedCornerShape(14.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text(
                        if (verificationId == null)
                            "ارسال کد پیامکی"
                        else
                            "تأیید و ورود"
                    )
                }
            }

            if (verificationId != null) {
                TextButton(
                    onClick = {
                        verificationId = null
                        code = ""
                        errorMessage = ""
                    }
                ) {
                    Text("تغییر شماره موبایل")
                }
            }

            Spacer(Modifier.height(16.dp))

            Text(
                errorMessage,
                color = if (errorMessage == "کد تأیید ارسال شد.")
                    MaterialTheme.colorScheme.primary
                else
                    MaterialTheme.colorScheme.error,
                fontSize = 13.sp
            )
        }
    }
}
